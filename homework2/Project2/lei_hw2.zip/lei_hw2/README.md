# Homework 2
## 使用方法
```bash
mkdir build
cd build
cmake ..
make

cd ..
./build/Sudoku_run sodu/easy.txt
./build/Sudoku_run sodu/medium.txt
./build/Sudoku_run sodu/hard.txt
./build/Sudoku_run sodu/hard+.txt
./build/Sudoku_run sodu/hard++.txt
```
## 实验结果
![](result.png)
## 剪枝思路
- 开始时先对数独进行扫描，按照行，列，box将出现过的数分别存储到数组中
- 对于每个为0的数组，进行数独填充
- 当一个数字没有违反行，列，box的要求时，才会将结果保存，并进行下一步