#include <fstream>
#include <iostream>
#include <string>
#include <vector>

class Sudoku {
public:
    Sudoku();
    ~Sudoku(){};

    void printSudoku();

    void printNumOfSolutions() {
        std::cout << "num of solution is: " << numOfSolutions_ << std::endl;
    };

    void readSudokuFromFile(const std::string &file_name);

    int getNumOfSolutions() { return numOfSolutions_; }

    void solveSudoku();

private:
    int rows_[9][10] = {0};
    int cols_[9][10] = {0};
    int boxes_[9][10] = {0};
    int sudoku_board_[9][9] = {0};

    int numOfSolutions_;

    void helper(int row, int col);

};
