#include <chrono>
#include <iostream>
#include "sudoku.hpp"

int main(const int argc, const char *argv[]) {
    /* read file */
    std::string file_name = argv[1];
    Sudoku test;
    test.readSudokuFromFile(file_name);

    /* start */
    std::chrono::time_point<std::chrono::system_clock> server_create_time_ =
        std::chrono::system_clock::now();

    /* solve problem */
    test.solveSudoku();

    /* end */
    auto current_time = std::chrono::system_clock::now();
    std::chrono::duration<double, std::milli> duration_mili = current_time - server_create_time_;
    std::cout << "solution_count = " << test.getNumOfSolutions() << std::endl;
    std::cout << "PrintDuration : duration_mili duration = " << (long)duration_mili.count()
              << " ms\n";
    if (test.getNumOfSolutions() == 1) {
        test.printSudoku();
    }
}
